package com.example.huskypet

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Datos compartidos entre el servicio de accesibilidad y la mascota. */
object Platforms {
    @Volatile var active = false          // la mascota lo pone en true mientras está en pantalla
    @Volatile var connected = false       // true cuando el usuario activó la accesibilidad de Luky
    @Volatile var rects: List<Rect> = emptyList()   // lugares de otras apps donde Luky se puede parar
}

/**
 * Solo mide POSICIONES de botones, textos e íconos que se ven en pantalla para que Luky
 * pueda subirse a ellos. No guarda ni envía textos, contraseñas ni nada (la app ni siquiera
 * tiene permiso de internet).
 */
class LukyAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var pending = false
    private var visited = 0

    private val scanTask = Runnable { pending = false; doScan() }
    private val beat = object : Runnable {            // refresca cada tanto aunque no haya eventos
        override fun run() {
            if (Platforms.active) doScan()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Platforms.connected = true
        handler.postDelayed(beat, 1500)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!Platforms.active || pending) return
        pending = true
        val ms = if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) 150L else 350L
        handler.postDelayed(scanTask, ms)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        Platforms.connected = false
        Platforms.rects = emptyList()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun doScan() {
        if (!Platforms.active) { Platforms.rects = emptyList(); return }
        val root = try { rootInActiveWindow } catch (_: Exception) { null }
        if (root == null) { Platforms.rects = emptyList(); return }
        val out = ArrayList<Rect>()
        visited = 0
        try { walk(root, out, 0) } catch (_: Exception) {}
        @Suppress("DEPRECATION") root.recycle()
        Platforms.rects = out.sortedBy { it.top }.take(200)
    }

    private fun walk(n: AccessibilityNodeInfo, out: MutableList<Rect>, depth: Int) {
        if (visited++ > 800 || depth > 40) return
        if (!n.isVisibleToUser) return
        val r = Rect()
        n.getBoundsInScreen(r)
        if (good(n, r)) out.add(r)
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, out, depth + 1)
            @Suppress("DEPRECATION") c.recycle()
        }
    }

    private fun good(n: AccessibilityNodeInfo, r: Rect): Boolean {
        val d = resources.displayMetrics
        if (r.width() < 40 * d.density || r.height() < 20 * d.density) return false
        if (r.height() > d.heightPixels * 0.6f) return false          // contenedores gigantes no cuentan
        if (r.width() > d.widthPixels * 1.05f) return false
        return n.isClickable || n.isLongClickable || n.isEditable ||
            !n.text.isNullOrEmpty() || !n.contentDescription.isNullOrEmpty()
    }
}
