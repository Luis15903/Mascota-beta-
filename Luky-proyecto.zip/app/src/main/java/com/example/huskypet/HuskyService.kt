package com.example.huskypet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Luky: mascota flotante (servicio en primer plano dibujado sobre todas las apps).
 *
 * Gestos:  toque = ladra | mantener = dormir/despertar | arrastrar y soltar = lanzarlo
 *          doble toque = modo juego (persigue tu dedo ~8 s después de la última vez que tocas)
 */
class HuskyService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.huskypet.STOP"
        const val ACTION_FEED = "com.example.huskypet.FEED"
        const val ACTION_HUNT = "com.example.huskypet.HUNT"
        const val ACTION_BALL = "com.example.huskypet.BALL"
        const val ACTION_HIDE = "com.example.huskypet.HIDE"
        private const val HIDE_OFF = 0
        private const val HIDE_COUNT = 1     // cuenta de 10 s mientras él corre
        private const val HIDE_HIDDEN = 2    // escondido, esperando que lo encuentres
        private const val CHANNEL_ID = "husky_channel"
        private const val NOTIF_ID = 7
        private val FRASES = listOf("¡Guau!", "¡Guau guau!", "¡Wuuuu!", "¿Jugamos?", "¡Hola! 🐾")

        // búsqueda del tesoro: letras de los cofres, fotos y mensaje final (cámbialos aquí)
        private val LETRAS_COFRES = listOf("L", "A")
        private val TESORO_FOTOS = intArrayOf(
            R.drawable.tesoro1, R.drawable.tesoro2, R.drawable.tesoro3, R.drawable.tesoro4, R.drawable.tesoro5)
        private const val TESORO_MENSAJE = "Gracias por volverte un gran tesoro en mi vida"
        private const val TESORO_FIRMA = "te amo, Ariana"
    }

    private enum class State { IDLE, WALK, SLEEP }
    private enum class Surf { FLOOR, WALL_L, WALL_R, CEIL }

    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var img: ImageView
    private lateinit var bubble: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private var touchLayer: View? = null
    private var loveView: FrameLayout? = null
    private var loveSlide: Runnable? = null
    private var loveHearts: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("luky", MODE_PRIVATE) }
    private fun petName() = (prefs.getString("name", "Luky") ?: "Luky").ifBlank { "Luky" }
    private fun mode() = prefs.getInt("mode", 0)   // 0 libre, 1 solo pasea, 2 quieto

    private var state = State.IDLE
    private var stateUntil = 0L
    private var dir = 1
    private var vx = 0f
    private var vy = 0f
    private var dragging = false
    private var surf = Surf.FLOOR   // en qué superficie está (suelo, paredes, techo)
    private var cdir = 1            // dirección al trepar: +1 sube / avanza, -1 baja
    private var barkUntil = 0L
    private var bubbleUntil = 0L
    private var bubbleText = "¡Guau!"
    private var screenW = 0
    private var screenH = 0
    private var currentSprite = 0
    private var lastX = Int.MIN_VALUE
    private var lastY = Int.MIN_VALUE
    private var grounded = false     // true cuando está parado sobre el suelo o sobre algo de otra app
    private var walkOff = false      // en este paseo se deja caer por los bordes de las plataformas

    // croquetas
    private class Kibble(var x: Float, var y: Float, var vy: Float, var landed: Boolean,
                         val born: Long, val size: Float, val rot: Float)
    private val food = ArrayList<Kibble>()
    private var foodView: FoodView? = null
    private var eatUntil = 0L
    private var feedBtn: View? = null
    private lateinit var feedLp: WindowManager.LayoutParams

    // búsqueda del tesoro
    private class Chest(val letter: String, val view: ChestView, val lp: WindowManager.LayoutParams)
    private val chests = ArrayList<Chest>()
    private val foundLetters = HashSet<String>()
    private var treasureView: FrameLayout? = null
    private var treasureSlide: Runnable? = null

    // modo pelota
    private var ballMode = false
    private var ballView: BallView? = null
    private lateinit var ballLp: WindowManager.LayoutParams
    private var bx = 0f
    private var by = 0f
    private var bvx = 0f
    private var bvy = 0f
    private var ballHeld = false       // el dedo la tiene agarrada
    private var ballCarried = false    // Luky la lleva en la boca
    private var ballReady = false      // ya la tiraste: Luky puede ir por ella
    private var ballReturnX = 0f       // adonde te la trae (donde la soltaste)

    // modo escondite
    private var hideMode = HIDE_OFF
    private var hideEnd = 0L
    private var hideSince = 0L
    private var hideRunDir = 1
    private var lastCount = -1

    // modo juego
    private var playing = false
    private var playUntil = 0L
    private var targetX = 0f
    private var targetY = 0f
    private var lastJumpAt = 0L
    private var chaseFast = false   // true cuando corre tras el dedo

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_FEED) feed()
        if (intent?.action == ACTION_HUNT) startHunt()
        if (intent?.action == ACTION_BALL) startBall()
        if (intent?.action == ACTION_HIDE) startHide()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        Platforms.active = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        updateScreen()

        root = FrameLayout(this)
        img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            currentSprite = R.drawable.husky
            setImageResource(currentSprite)
        }
        root.addView(img, FrameLayout.LayoutParams(dp(130), dp(130), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        bubble = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#1b1b1b"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dpf(14f)
                setStroke(dp(2), Color.parseColor("#1b1b1b"))
            }
            visibility = View.INVISIBLE
        }
        root.addView(bubble, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        lp = WindowManager.LayoutParams(
            dp(140), dp(170),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Random.nextInt(0, (screenW - dp(140)).coerceAtLeast(1))
            y = 0   // empieza arriba y cae al suelo
        }
        wm.addView(root, lp)
        addFeedButton()
        setupTouch()
        setState(State.IDLE)
        handler.post(loop)
    }

    // ---------------- Pantalla / rotación ----------------
    private fun updateScreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels; screenH = dm.heightPixels
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateScreen()
        release()
        lp.x = lp.x.coerceIn(0, (screenW - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, groundY().coerceAtLeast(0))
        applyPos()
        if (ballMode) {
            bx = bx.coerceIn(ballR(), (screenW - ballR()).coerceAtLeast(ballR()))
            by = by.coerceIn(ballR(), (baseFeet() - ballR()).coerceAtLeast(ballR()))
        }
        for (ch in chests) {
            ch.lp.x = ch.lp.x.coerceIn(0, (screenW - ch.lp.width).coerceAtLeast(0))
            ch.lp.y = ch.lp.y.coerceIn(0, (screenH - ch.lp.height).coerceAtLeast(0))
            try { wm.updateViewLayout(ch.view, ch.lp) } catch (_: Exception) {}
        }
        feedBtn?.let {
            feedLp.x = feedLp.x.coerceIn(0, (screenW - feedLp.width).coerceAtLeast(0))
            feedLp.y = feedLp.y.coerceIn(0, (screenH - feedLp.height).coerceAtLeast(0))
            try { wm.updateViewLayout(it, feedLp) } catch (_: Exception) {}
        }
    }

    // ---------------- Táctil ----------------
    private fun setupTouch() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { ladrar(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (playing) endPlay() else startPlay()
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                if (!playing) { release(); setState(if (state == State.SLEEP) State.IDLE else State.SLEEP) }
            }
        })
        var offX = 0f; var offY = 0f; var startX = 0f; var startY = 0f
        var lastRawX = 0f; var lastRawY = 0f; var lastT = 0L
        var velX = 0f; var velY = 0f
        root.setOnTouchListener { _, e ->
            if (hideMode == HIDE_HIDDEN) {            // escondite: un toque y lo encontraste
                if (e.actionMasked == MotionEvent.ACTION_DOWN) foundHide()
                return@setOnTouchListener true
            }
            gd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    startX = e.rawX; startY = e.rawY
                    offX = lp.x - e.rawX; offY = lp.y - e.rawY
                    lastRawX = e.rawX; lastRawY = e.rawY; lastT = e.eventTime
                    velX = 0f; velY = 0f
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && hypot(e.rawX - startX, e.rawY - startY) > dp(10)) {
                        dragging = true; vx = 0f; vy = 0f; surf = Surf.FLOOR
                        if (state == State.SLEEP && !playing) setState(State.IDLE)
                    }
                    if (dragging) {
                        val dt = (e.eventTime - lastT).coerceAtLeast(1L)
                        velX = 0.6f * velX + 0.4f * (e.rawX - lastRawX) / dt
                        velY = 0.6f * velY + 0.4f * (e.rawY - lastRawY) / dt
                        lastRawX = e.rawX; lastRawY = e.rawY; lastT = e.eventTime
                        lp.x = (e.rawX + offX).toInt().coerceIn(0, (screenW - lp.width).coerceAtLeast(0))
                        lp.y = (e.rawY + offY).toInt().coerceIn(0, groundY().coerceAtLeast(0))
                        applyPos()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        if (e.eventTime - lastT > 80) { velX = 0f; velY = 0f }   // soltó despacio
                        val maxV = dpf(30f)
                        vx = (velX * 33f).coerceIn(-maxV, maxV)    // px/ms -> px/frame
                        vy = (velY * 33f).coerceIn(-maxV, maxV)
                    }
                    dragging = false
                }
            }
            true
        }
    }

    // ---------------- Modo juego ----------------
    private fun startPlay() {
        if (playing) return
        release()
        playing = true
        setState(State.IDLE)
        playUntil = SystemClock.uptimeMillis() + 8000
        targetX = (lp.x + lp.width / 2).toFloat()
        targetY = lp.y.toFloat()
        say("¡Modo juego! Toca la pantalla 🐾", 2500)
        handler.post {
            if (!playing || touchLayer != null) return@post
            val layer = TrailView(this)
            val tlp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(layer, tlp)
            touchLayer = layer
            // re-agrega al husky para que quede POR ENCIMA de la capa (así lo puedes tocar)
            // el husky no intercepta toques en modo juego: así el dedo siempre dibuja sobre la capa
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.removeView(root)
            wm.addView(root, lp)
        }
    }

    private fun endPlay() {
        if (!playing) return
        playing = false
        touchLayer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        touchLayer = null
        lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        setState(State.IDLE)
        say("¡Qué divertido!", 1500)
    }

    // ---------------- Dibujar un corazón (modo juego) ----------------
    private inner class TrailView(ctx: Context) : View(ctx) {
        private val strokes = ArrayList<ArrayList<PointF>>()   // varios trazos: acepta corazones hechos en 2 tiempos
        private var lastUpAt = 0L
        private val clearTrail = Runnable { strokes.clear(); invalidate() }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF4D8D"); style = Paint.Style.STROKE
            strokeWidth = dpf(6f); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean { handler.post { endPlay() }; return true }
        })

        override fun onTouchEvent(e: MotionEvent): Boolean {
            gd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    removeCallbacks(clearTrail)
                    if (SystemClock.uptimeMillis() - lastUpAt > 900) strokes.clear()
                    strokes.add(arrayListOf(PointF(e.rawX, e.rawY)))
                    targetX = e.rawX; targetY = e.rawY
                    playUntil = Long.MAX_VALUE / 2           // mientras el dedo esté abajo
                }
                MotionEvent.ACTION_MOVE -> {
                    if (strokes.isEmpty()) strokes.add(ArrayList())
                    strokes.last().add(PointF(e.rawX, e.rawY))
                    targetX = e.rawX; targetY = e.rawY
                    playUntil = Long.MAX_VALUE / 2
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    lastUpAt = SystemClock.uptimeMillis()
                    playUntil = lastUpAt + 8000
                    if (e.actionMasked == MotionEvent.ACTION_UP && isHeart(strokes)) {
                        strokes.clear()
                        handler.post { endPlay(); showLove(); say("💕", 3000) }
                    } else {
                        postDelayed(clearTrail, 900)
                    }
                }
            }
            invalidate()
            return true
        }

        override fun onDraw(c: Canvas) {
            for (s in strokes) {
                if (s.size < 2) continue
                val path = Path()
                path.moveTo(s[0].x, s[0].y)
                for (i in 1 until s.size) path.lineTo(s[i].x, s[i].y)
                c.drawPath(path, paint)
            }
        }
    }

    /**
     * Reconoce un corazón de forma MUY permisiva: acepta trazos abiertos, chuecos, chicos o grandes,
     * hechos en uno o dos trazos. Solo pide: tamaño mínimo, trazo largo, punta abajo hacia el centro
     * y que sea más ancho arriba que abajo (así un círculo o una raya no cuentan).
     */
    private fun isHeart(strokes: List<List<PointF>>): Boolean {
        val p = strokes.flatten()
        if (p.size < 10) return false
        var a = Float.MAX_VALUE; var b = -Float.MAX_VALUE
        var c = Float.MAX_VALUE; var d = -Float.MAX_VALUE
        for (q in p) { a = min(a, q.x); b = maxOf(b, q.x); c = min(c, q.y); d = maxOf(d, q.y) }
        val w = b - a; val h = d - c; val cxm = (a + b) / 2f
        if (w < dp(70) || h < dp(70)) return false
        if (w / h < 0.5f || w / h > 2.0f) return false

        var len = 0f                                    // largo total del trazo
        for (s in strokes) for (i in 1 until s.size) len += hypot(s[i].x - s[i - 1].x, s[i].y - s[i - 1].y)
        if (len < 2.3f * maxOf(w, h)) return false

        var tip = p[0]                                  // punta: lo más bajo, más o menos al centro
        for (q in p) if (q.y > tip.y) tip = q
        if (abs(tip.x - cxm) > 0.3f * w) return false

        var tMin = Float.MAX_VALUE; var tMax = -Float.MAX_VALUE   // ancho arriba (40% superior)
        var bMin = Float.MAX_VALUE; var bMax = -Float.MAX_VALUE   // ancho abajo (25% inferior)
        for (q in p) {
            if (q.y < c + 0.4f * h) { tMin = min(tMin, q.x); tMax = maxOf(tMax, q.x) }
            if (q.y > d - 0.25f * h) { bMin = min(bMin, q.x); bMax = maxOf(bMax, q.x) }
        }
        if (tMin == Float.MAX_VALUE || bMin == Float.MAX_VALUE) return false
        val taper = (tMax - tMin) / maxOf(bMax - bMin, 0.05f * w)
        if (taper < 1.35f) return false

        var yc = Float.MAX_VALUE; var yl = Float.MAX_VALUE; var yr = Float.MAX_VALUE   // muesca de arriba
        for (s in strokes) for (i in s.indices) {
            val q = s[i]; val dx = q.x - cxm
            if (abs(dx) < 0.1f * w) yc = min(yc, q.y)
            if (dx < 0) yl = min(yl, q.y) else yr = min(yr, q.y)
            if (i > 0) {
                val e = s[i - 1]; val dx0 = e.x - cxm
                if (dx0 * dx < 0) { val k = dx0 / (dx0 - dx); yc = min(yc, e.y + k * (q.y - e.y)) }
            }
        }
        val notch = yc != Float.MAX_VALUE && yc < d - 0.35f * h && yc > maxOf(yl, yr) + 0.04f * h
        return notch || taper >= 1.6f
    }

    // ---------------- Pantalla de amor ----------------
    private fun showLove() {
        if (loveView != null) return
        val fotos = intArrayOf(R.drawable.foto1, R.drawable.foto2, R.drawable.foto3, R.drawable.foto4)
        val box = FrameLayout(this)
        box.setBackgroundColor(Color.parseColor("#E6000000"))

        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(fotos[0])
        }
        box.addView(photo, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ).apply { setMargins(dp(20), dp(60), dp(20), dp(200)) })

        val msg = TextView(this).apply {
            text = "Te quiero mucho,\nno te olvides de mí, papi"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(8f, 0f, 2f, Color.BLACK)
        }
        box.addView(msg, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ).apply { bottomMargin = dp(90) })

        val hint = TextView(this).apply {
            text = "toca para cerrar"
            textSize = 12f
            setTextColor(Color.parseColor("#99FFFFFF"))
            gravity = Gravity.CENTER
        }
        box.addView(hint, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ).apply { bottomMargin = dp(50) })

        box.setOnClickListener { hideLove() }
        val wlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(box, wlp)
        loveView = box

        var i = 0
        val slide = object : Runnable {             // las fotos cambian con un fundido
            override fun run() {
                photo.animate().alpha(0f).setDuration(350).withEndAction {
                    i = (i + 1) % fotos.size
                    photo.setImageResource(fotos[i])
                    photo.animate().alpha(1f).setDuration(350).start()
                }.start()
                handler.postDelayed(this, 2600)
            }
        }
        loveSlide = slide
        handler.postDelayed(slide, 2600)

        val hearts = object : Runnable {            // corazones flotando
            override fun run() {
                val h = TextView(this@HuskyService).apply {
                    text = listOf("❤️", "💕", "🤍", "💗").random()
                    textSize = Random.nextInt(18, 34).toFloat()
                }
                box.addView(h, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    leftMargin = Random.nextInt(0, (screenW - dp(40)).coerceAtLeast(1))
                    topMargin = screenH - dp(120)
                })
                h.animate().translationY(-screenH * 0.7f).alpha(0f).setDuration(3200)
                    .withEndAction { box.removeView(h) }.start()
                handler.postDelayed(this, 350)
            }
        }
        loveHearts = hearts
        handler.post(hearts)
    }

    private fun hideLove() {
        loveSlide?.let { handler.removeCallbacks(it) }
        loveHearts?.let { handler.removeCallbacks(it) }
        loveSlide = null; loveHearts = null
        loveView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        loveView = null
    }

    // ---------------- Modo pelota ----------------
    private fun ballR() = dpf(22f)

    private fun startBall() {
        stopHide()
        stopBall()
        if (playing) endPlay()
        release()
        ballMode = true
        ballHeld = false; ballCarried = false; ballReady = false
        ballReturnX = screenW / 2f
        val r = ballR()
        bx = Random.nextInt(dp(60), (screenW - dp(60)).coerceAtLeast(dp(61))).toFloat()
        by = dp(110).toFloat()
        bvx = 0f; bvy = 0f

        val view = BallView(this)
        ballLp = WindowManager.LayoutParams(
            (r * 2).toInt(), (r * 2).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (bx - r).toInt(); y = (by - r).toInt() }

        var lastRawX = 0f; var lastRawY = 0f; var lastT = 0L
        var velX = 0f; var velY = 0f
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ballHeld = true
                    bvx = 0f; bvy = 0f
                    velX = 0f; velY = 0f
                    lastRawX = e.rawX; lastRawY = e.rawY; lastT = e.eventTime
                    bx = e.rawX.coerceIn(r, (screenW - r).coerceAtLeast(r))
                    by = e.rawY.coerceIn(r, (screenH - r).coerceAtLeast(r))
                }
                MotionEvent.ACTION_MOVE -> {
                    val dt = (e.eventTime - lastT).coerceAtLeast(1L)
                    velX = 0.6f * velX + 0.4f * (e.rawX - lastRawX) / dt
                    velY = 0.6f * velY + 0.4f * (e.rawY - lastRawY) / dt
                    lastRawX = e.rawX; lastRawY = e.rawY; lastT = e.eventTime
                    bx = e.rawX.coerceIn(r, (screenW - r).coerceAtLeast(r))
                    by = e.rawY.coerceIn(r, (screenH - r).coerceAtLeast(r))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ballHeld = false
                    if (e.eventTime - lastT > 80) { velX = 0f; velY = 0f }   // la soltó despacio
                    val maxV = dpf(40f)
                    bvx = (velX * 33f).coerceIn(-maxV, maxV)                 // px/ms -> px/frame
                    bvy = (velY * 33f).coerceIn(-maxV, maxV)
                    ballReady = true
                    ballReturnX = e.rawX.coerceIn(dp(40).toFloat(), (screenW - dp(40)).toFloat())
                }
            }
            true
        }
        wm.addView(view, ballLp)
        ballView = view
        say("¡Tírame la pelota! Arrástrala y suéltala", 4000)
    }

    private fun stopBall() {
        ballMode = false
        ballCarried = false
        ballHeld = false
        ballView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        ballView = null
    }

    private fun setBallTouchable(on: Boolean) {
        val v = ballView ?: return
        ballLp.flags = if (on) ballLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else ballLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, ballLp) } catch (_: Exception) {}
    }

    /** Física de la pelota: gravedad, rebotes y rodar. Si Luky la lleva, va en su boca. */
    private fun updateBall() {
        val bv = ballView ?: return
        val r = ballR()
        if (ballCarried) {
            bx = (lp.x + lp.width / 2) + dir * dpf(46f)
            by = (lp.y + lp.height) - dpf(46f)
            bvx = 0f; bvy = 0f
        } else if (!ballHeld) {
            bvy += dpf(0.9f)
            bx += bvx; by += bvy
            val floor = baseFeet() - r
            if (by >= floor) {
                by = floor
                bvy = if (abs(bvy) > dpf(3f)) -bvy * 0.55f else 0f
                bvx *= 0.93f
                if (abs(bvx) < 0.2f) bvx = 0f
            }
            if (bx < r) { bx = r; bvx = -bvx * 0.7f }
            if (bx > screenW - r) { bx = screenW - r; bvx = -bvx * 0.7f }
            if (by < r) { by = r; bvy = -bvy * 0.5f }
            bv.angle += bvx * 3f
            bv.invalidate()
        }
        val nx = (bx - r).toInt(); val ny = (by - r).toInt()
        if (nx != ballLp.x || ny != ballLp.y) {
            ballLp.x = nx; ballLp.y = ny
            try { wm.updateViewLayout(bv, ballLp) } catch (_: Exception) {}
        }
    }

    /** Luky espera a que tires la pelota, corre por ella, la agarra y te la trae. */
    private fun ballBehave(now: Long): Boolean {
        if (state == State.SLEEP) setState(State.IDLE)
        chaseFast = false
        val cx = lp.x + lp.width / 2
        if (ballCarried) {
            val dx = ballReturnX - cx
            if (abs(dx) <= dp(30)) { dropBall(now); return false }
            return walkToward(dx)
        }
        if (!ballReady || ballHeld) return false
        val dx = bx - cx
        val settled = by >= baseFeet() - ballR() - dp(8) && abs(bvx) < dpf(3f) && abs(bvy) < dpf(3f)
        if (settled && abs(dx) <= dp(40)) {
            ballCarried = true
            ballReady = false
            setBallTouchable(false)
            barkUntil = now + 350
            say("¡La tengo!", 1200)
            return false
        }
        if (abs(dx) <= dp(20)) return false
        return walkToward(dx)
    }

    private fun dropBall(now: Long) {
        ballCarried = false
        ballReady = false
        bvx = dir * dpf(1.5f)
        bvy = -dpf(5f)
        setBallTouchable(true)
        barkUntil = now + 350
        say("¡Toma! Tírala otra vez", 2500)
    }

    // ---------------- Modo escondite ----------------
    private fun startHide() {
        stopBall()
        if (hideMode == HIDE_HIDDEN) restoreFromHidden()
        if (playing) endPlay()
        release()
        hideMode = HIDE_COUNT
        hideEnd = SystemClock.uptimeMillis() + 10000
        hideRunDir = if (Random.nextBoolean()) 1 else -1
        lastCount = -1
    }

    /** Durante la cuenta Luky corre de un lado a otro. */
    private fun hideRun(now: Long): Boolean {
        chaseFast = true
        dir = hideRunDir
        lp.x += dir * dp(9)
        if (lp.x <= 0 || lp.x >= screenW - lp.width) { clampX(); hideRunDir = -hideRunDir }
        val left = ((hideEnd - now) / 1000L).toInt() + 1
        if (left != lastCount) { lastCount = left; say("Cuenta... $left", 1100) }
        return true
    }

    /** Se acabó la cuenta: Luky se encoge, se vuelve casi transparente y aparece en un lugar al azar. */
    private fun beginHidden(now: Long) {
        hideMode = HIDE_HIDDEN
        hideSince = now
        release()
        grounded = false
        val w = dp(80)
        lp.width = w; lp.height = w            // ventana chica: solo se toca donde está él
        lp.x = Random.nextInt(dp(8), (screenW - w - dp(8)).coerceAtLeast(dp(9)))
        lp.y = Random.nextInt(dp(70), (screenH - w - dp(100)).coerceAtLeast(dp(71)))
        currentSprite = R.drawable.husky
        img.setImageResource(currentSprite)
        bubble.visibility = View.INVISIBLE
        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        lastX = lp.x; lastY = lp.y
    }

    private fun stepHidden(now: Long) {
        val since = now - hideSince
        var pulse = 0f                         // desde los 15 s suelta un destello cada 12 s como pista
        if (since > 15000) {
            val p = (since - 15000) % 12000
            if (p < 900) pulse = sin(PI * p / 900.0).toFloat()
        }
        img.pivotX = img.width / 2f
        img.pivotY = img.height.toFloat()
        img.rotation = 0f; img.translationX = 0f; img.translationY = 0f
        val sc = 0.4f + 0.2f * pulse
        img.scaleX = sc; img.scaleY = sc
        img.alpha = (0.3f + 0.08f * sin(now / 600.0).toFloat() + 0.6f * pulse).coerceIn(0f, 1f)
        if (bubble.visibility != View.INVISIBLE) bubble.visibility = View.INVISIBLE
    }

    /** Vuelve al tamaño normal (sin hablar) y lo deja caer al suelo. */
    private fun restoreFromHidden() {
        hideMode = HIDE_OFF
        img.alpha = 1f
        val bottom = lp.y + lp.height
        val cxm = lp.x + lp.width / 2
        lp.width = dp(140); lp.height = dp(170)
        lp.x = (cxm - lp.width / 2).coerceIn(0, (screenW - lp.width).coerceAtLeast(0))
        lp.y = (bottom - lp.height).coerceAtLeast(0)
        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
        lastX = lp.x; lastY = lp.y
        vx = 0f; vy = 0f
        setState(State.IDLE)
    }

    private fun foundHide() {
        if (hideMode != HIDE_HIDDEN) return
        restoreFromHidden()
        vy = -dpf(10f)                          // salta de alegría
        barkUntil = SystemClock.uptimeMillis() + 350
        say("¡Me encontraste! 🐾", 3000)
    }

    private fun stopHide() {
        if (hideMode == HIDE_HIDDEN) restoreFromHidden()
        hideMode = HIDE_OFF
    }

    // ---------------- Búsqueda del tesoro ----------------
    /** Esconde un cofre por cada letra en un lugar al azar de la pantalla (encima de cualquier app). */
    private fun startHunt() {
        clearHunt()
        hideTreasure()
        foundLetters.clear()
        val size = dp(84)
        val maxX = (screenW - size - dp(8)).coerceAtLeast(dp(9))
        val maxY = (screenH - size - dp(110)).coerceAtLeast(dp(71))
        val placed = ArrayList<Rect>()
        for (letter in LETRAS_COFRES) {
            var px: Int
            var py: Int
            var tries = 0
            do {                                            // busca un lugar libre (sin pisar otro cofre ni el botón 🍖)
                px = Random.nextInt(dp(8), maxX)
                py = Random.nextInt(dp(70), maxY)
                tries++
                val r = Rect(px, py, px + size, py + size)
                val busy = placed.any { Rect.intersects(it, r) } ||
                    (feedBtn != null && Rect.intersects(
                        Rect(feedLp.x, feedLp.y, feedLp.x + feedLp.width, feedLp.y + feedLp.height), r))
            } while (busy && tries < 40)
            placed.add(Rect(px, py, px + size, py + size))

            val view = ChestView(this, letter)
            val clp = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = px; y = py }
            val chest = Chest(letter, view, clp)
            view.setOnClickListener { onChestTapped(chest) }
            wm.addView(view, clp)
            chests.add(chest)
        }
        say("¡Escondí ${LETRAS_COFRES.size} cofres! Búscalos: ${LETRAS_COFRES.joinToString(" y ")}", 4000)
    }

    private fun onChestTapped(ch: Chest) {
        if (ch.view.opened) return
        ch.view.open()
        foundLetters.add(ch.letter)
        // la ventana crece un momento para que quepa el estallido de estrellas (y deja pasar los toques)
        val big = dp(240)
        ch.lp.x = ch.lp.x + ch.lp.width / 2 - big / 2
        ch.lp.y = ch.lp.y + ch.lp.height / 2 - big / 2
        ch.lp.width = big
        ch.lp.height = big
        ch.lp.flags = ch.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(ch.view, ch.lp) } catch (_: Exception) {}
        handler.postDelayed({ removeChest(ch) }, 1300)

        if (foundLetters.size >= LETRAS_COFRES.size) {
            say("¡Encontraste los dos cofres!", 2500)
            handler.postDelayed({ showTreasure() }, 1100)
        } else {
            val falta = LETRAS_COFRES.filter { it !in foundLetters }.joinToString(" y ")
            say("¡Cofre ${ch.letter}! Falta el $falta", 2800)
        }
    }

    private fun removeChest(ch: Chest) {
        try { wm.removeView(ch.view) } catch (_: Exception) {}
        chests.remove(ch)
    }

    private fun clearHunt() {
        for (ch in chests.toList()) removeChest(ch)
    }

    /** Pantalla final: cielo de estrellas y cometas, fotos que cambian con fundido y el mensaje. */
    private fun showTreasure() {
        if (treasureView != null) return
        val gold = Color.parseColor("#FFD08A")
        val box = FrameLayout(this)
        box.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#050818"), Color.parseColor("#141235"), Color.parseColor("#2B1238")))
        box.addView(StarFieldView(this), FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(56), dp(24), dp(40))
        }

        val photo = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            maxHeight = (screenH * 0.52f).toInt()
            maxWidth = (screenW - dp(80)).coerceAtLeast(dp(120))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply { setColor(Color.parseColor("#F7F1E6")); cornerRadius = dpf(6f) }
            setImageResource(TESORO_FOTOS[0])
            rotation = -2f
        }
        col.addView(photo, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val dotViews = TESORO_FOTOS.map {
            View(this).also { v ->
                dots.addView(v, LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                })
            }
        }
        fun paintDots(active: Int) {
            dotViews.forEachIndexed { i, v ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == active) gold else Color.parseColor("#55FFFFFF"))
                }
            }
        }
        paintDots(0)
        col.addView(dots, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(18) })

        val msg = TextView(this).apply {
            text = TESORO_MENSAJE
            textSize = 23f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setLineSpacing(0f, 1.1f)
            setShadowLayer(dpf(10f), 0f, 0f, Color.parseColor("#99FFD08A"))
        }
        col.addView(msg, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(22) })

        val firma = TextView(this).apply {
            text = TESORO_FIRMA
            textSize = 30f
            typeface = Typeface.create("serif", Typeface.ITALIC)
            gravity = Gravity.CENTER
            setTextColor(gold)
            setShadowLayer(dpf(12f), 0f, 0f, Color.parseColor("#AAFFD08A"))
        }
        col.addView(firma, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        val hint = TextView(this).apply {
            text = "toca para cerrar"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#80FFFFFF"))
        }
        col.addView(hint, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })

        box.addView(col, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.setOnClickListener { hideTreasure() }

        val wlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(box, wlp)
        treasureView = box

        // entrada: el cielo aparece y el mensaje sube un poquito después
        box.alpha = 0f
        box.animate().alpha(1f).setDuration(600).start()
        for ((n, v) in listOf<View>(msg, firma).withIndex()) {
            v.alpha = 0f
            v.translationY = dpf(14f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(500L + n * 350L).setDuration(600).start()
        }

        var i = 0
        val slide = object : Runnable {
            override fun run() {
                photo.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(380).withEndAction {
                    i = (i + 1) % TESORO_FOTOS.size
                    photo.setImageResource(TESORO_FOTOS[i])
                    photo.rotation = if (i % 2 == 0) -2f else 2f
                    paintDots(i)
                    photo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380).start()
                }.start()
                handler.postDelayed(this, 3300)
            }
        }
        treasureSlide = slide
        handler.postDelayed(slide, 3300)
    }

    private fun hideTreasure() {
        treasureSlide?.let { handler.removeCallbacks(it) }
        treasureSlide = null
        treasureView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        treasureView = null
    }

    // ---------------- Comportamiento ----------------
    private fun groundY() = screenH - lp.height - dp(96)   // sube/baja este número para ajustar el "suelo"

    private fun applyPos() {
        if (lp.x != lastX || lp.y != lastY) {
            wm.updateViewLayout(root, lp)
            lastX = lp.x; lastY = lp.y
        }
    }

    private fun setState(s: State) {
        state = s
        stateUntil = SystemClock.uptimeMillis() + Random.nextLong(4000, 9000)
        if (s == State.WALK) { dir = if (Random.nextBoolean()) 1 else -1; walkOff = Random.nextInt(100) < 35 }
    }

    private fun say(text: String, ms: Long) {
        bubbleText = text
        bubbleUntil = SystemClock.uptimeMillis() + ms
    }

    private fun ladrar() {
        if (state == State.SLEEP) setState(State.IDLE)
        barkUntil = SystemClock.uptimeMillis() + 350
        say(FRASES.random(), 1400)
    }

    private fun jump() {
        if (surf == Surf.FLOOR && grounded) vy = -dpf(13f)
    }

    private fun clampX() {
        lp.x = lp.x.coerceIn(0, (screenW - lp.width).coerceAtLeast(0))
    }

    private fun wallBottom() = groundY() + dp(40)

    // ---------------- Botón flotante de croquetas (siempre visible, se puede arrastrar) ----------------
    private fun addFeedButton() {
        val size = dp(52)
        val b = TextView(this).apply {
            text = "🍖"
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC180B2B"))
                setStroke(dp(2), Color.parseColor("#F5A623"))
            }
        }
        feedLp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - size - dp(8)).coerceAtLeast(0)
            y = (screenH * 0.45f).toInt()
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = feedLp.x; oy = feedLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (hypot(e.rawX - sx, e.rawY - sy) > dp(10)) moved = true
                    if (moved) {
                        feedLp.x = (ox + e.rawX - sx).toInt().coerceIn(0, (screenW - size).coerceAtLeast(0))
                        feedLp.y = (oy + e.rawY - sy).toInt().coerceIn(0, (screenH - size).coerceAtLeast(0))
                        try { wm.updateViewLayout(b, feedLp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) feed()
            }
            true
        }
        wm.addView(b, feedLp)
        feedBtn = b
    }

    // ---------------- Croquetas ----------------
    private fun feed() {
        if (surf != Surf.FLOOR) release()
        ensureFoodLayer()
        val cx = lp.x + lp.width / 2
        val minX = lp.width / 2
        val maxX = (screenW - lp.width / 2).coerceAtLeast(minX)
        repeat(6) { i ->
            val x = (cx + Random.nextInt(-dp(150), dp(150))).coerceIn(minX, maxX)
            food.add(Kibble(x.toFloat(), -dpf(10f) - i * dpf(40f), 0f, false,
                SystemClock.uptimeMillis(), dpf(Random.nextInt(5, 8).toFloat()), Random.nextInt(0, 360).toFloat()))
        }
        while (food.size > 24) food.removeAt(0)
        say("¡Croquetas! 🍖", 1800)
    }

    private fun ensureFoodLayer() {
        if (foodView != null) return
        val layer = FoodView(this)
        val flp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(layer, flp)
        foodView = layer
        try { wm.removeView(root); wm.addView(root, lp) } catch (_: Exception) {}   // Luky queda por encima
    }

    private fun removeFoodLayer() {
        foodView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        foodView = null
    }

    private fun updateFood(now: Long) {
        if (food.isEmpty()) return
        val it = food.iterator()
        while (it.hasNext()) {
            val k = it.next()
            if (now - k.born > 60000) { it.remove(); continue }          // se acaban solas al minuto
            if (!k.landed) {
                k.vy += dpf(0.9f)
                val ny = k.y + k.vy
                val s = support(k.x.toInt(), k.y.toInt(), 0)
                if (ny >= s) { k.y = s.toFloat(); k.vy = 0f; k.landed = true } else k.y = ny
            } else {
                val s = support(k.x.toInt(), k.y.toInt(), dp(6))
                if (s > k.y + dp(2)) { k.landed = false; k.vy = 0f }      // la app se movió: cae
                else if (s < k.y) k.y = s.toFloat()
            }
        }
        if (food.isEmpty()) removeFoodLayer() else foodView?.invalidate()
    }

    private fun walkToward(dx: Float): Boolean {
        if (abs(dx) > dp(16)) dir = if (dx > 0) 1 else -1
        val fast = abs(dx) > dp(90)
        lp.x += dir * (if (fast) dp(7) else dp(4))
        clampX()
        chaseFast = fast
        return true
    }

    private fun hopTo(tx: Float, topY: Int) {
        val g = dpf(0.9f)
        val feet = lp.y + lp.height
        val cx = lp.x + lp.width / 2
        val h = (feet - topY).toFloat()
        val v = sqrt(2f * g * (h + dpf(16f)))
        val t = (v + sqrt(maxOf(v * v - 2f * g * h, 0f))) / g
        vx = ((tx - cx) / t).coerceIn(-dpf(10f), dpf(10f))
        vy = -v
        if (vx > 0.5f) dir = 1 else if (vx < -0.5f) dir = -1
    }

    /** Va hacia la croqueta más cercana y se la come. Devuelve true si se está moviendo. */
    private fun goEat(now: Long): Boolean {
        if (state == State.SLEEP) setState(State.IDLE)
        chaseFast = false
        if (now < eatUntil) return false
        val feet = lp.y + lp.height
        val cx = lp.x + lp.width / 2
        var target: Kibble? = null
        var bestD = Float.MAX_VALUE
        for (k in food) {
            if (!k.landed) continue
            if (feet - k.y > dp(230)) continue                     // demasiado alto para llegar
            val d = abs(k.x - cx) + abs(k.y - feet) * 2f
            if (d < bestD) { bestD = d; target = k }
        }
        val k = target ?: return false
        val dx = k.x - cx
        val dy = k.y - feet                                        // negativo = la croqueta está más arriba
        val atWall = (dx < 0 && lp.x <= 0) || (dx > 0 && lp.x >= screenW - lp.width)
        if (abs(dy) <= dp(26) && (abs(dx) <= dp(16) || atWall)) {
            food.remove(k)
            eatUntil = now + 450
            barkUntil = now + 350
            say(if (food.isEmpty()) "¡Qué rico! 🐾" else "¡Ñam! 😋", 900)
            return false
        }
        if (dy < -dp(26) && usePlatforms() && abs(dx) <= dp(150)) {   // está arriba: salta
            if (now - lastJumpAt > 700) { hopTo(k.x, k.y.toInt()); lastJumpAt = now }
            return false
        }
        return walkToward(dx)
    }

    private inner class FoodView(ctx: Context) : View(ctx) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9A5B2E") }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#5A3416"); style = Paint.Style.STROKE; strokeWidth = dpf(1.6f)
        }
        private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C98A52") }

        override fun onDraw(c: Canvas) {
            for (k in food) {
                val r = k.size
                c.save()
                c.translate(k.x, k.y - r * 0.8f)
                c.rotate(k.rot)
                c.drawOval(-r, -r * 0.8f, r, r * 0.8f, fill)
                c.drawOval(-r, -r * 0.8f, r, r * 0.8f, edge)
                c.drawCircle(-r * 0.3f, -r * 0.25f, r * 0.22f, shine)
                c.restore()
            }
        }
    }

    // ---------------- Plataformas: cosas de otras apps donde Luky se puede parar ----------------
    private fun baseFeet() = screenH - dp(96)               // pies de Luky cuando está en el suelo de verdad
    private fun usePlatforms() = mode() == 0 && !ballMode && hideMode == HIDE_OFF &&
        Platforms.connected && Platforms.rects.isNotEmpty()

    /** Altura (de los pies) del suelo más alto que está a la altura de los pies o debajo; [tol] = escalón que puede subir. */
    private fun support(cx: Int, feet: Int, tol: Int): Int {
        var best = baseFeet()
        if (!usePlatforms()) return best
        for (r in Platforms.rects) {
            val t = r.top
            if (t < best && t >= feet - tol && t >= lp.height && cx >= r.left && cx <= r.right) best = t
        }
        return best
    }

    /** Salta a una plataforma cercana que esté más arriba (un botón, un texto, un ícono...). */
    private fun tryHop(): Boolean {
        if (!usePlatforms() || surf != Surf.FLOOR || !grounded) return false
        val feet = lp.y + lp.height
        val cx = lp.x + lp.width / 2
        var best: Rect? = null
        var bestScore = Int.MAX_VALUE
        for (r in Platforms.rects) {
            val h = feet - r.top
            if (h < dp(30) || h > dp(230) || r.width() < dp(60)) continue
            val dx = if (cx < r.left) r.left - cx else if (cx > r.right) cx - r.right else 0
            if (dx > dp(160)) continue
            val score = h + dx + Random.nextInt(0, dp(80))   // un poco de azar para que no sea siempre el mismo
            if (score < bestScore) { bestScore = score; best = r }
        }
        val r = best ?: return false
        val g = dpf(0.9f)
        val h = (feet - r.top).toFloat()
        val v = sqrt(2f * g * (h + dpf(16f)))                       // velocidad para llegar un poquito más arriba
        val t = (v + sqrt(maxOf(v * v - 2f * g * h, 0f))) / g       // cuadros hasta caer en la plataforma
        val tx = cx.coerceIn(r.left + dp(24), r.right - dp(24))
        vx = ((tx - cx) / t).coerceIn(-dpf(10f), dpf(10f))
        vy = -v
        if (vx > 0.5f) dir = 1 else if (vx < -0.5f) dir = -1
        return true
    }

    private fun release() {                     // suelta la pared/techo y cae
        surf = Surf.FLOOR
        vx = 0f; vy = 0f
        setState(State.IDLE)
    }

    private fun startClimb(left: Boolean) {
        surf = if (left) Surf.WALL_L else Surf.WALL_R
        lp.x = if (left) 0 else screenW - lp.width
        lp.y = wallBottom()
        cdir = 1
        setState(State.WALK)
        stateUntil = SystemClock.uptimeMillis() + 25000   // aguanta hasta llegar arriba
        vx = 0f; vy = 0f
        lastX = Int.MIN_VALUE; lastY = Int.MIN_VALUE      // fuerza reposicionar la ventana
    }

    private fun climb(now: Long) {
        val sp = dp(3)
        when (surf) {
            Surf.WALL_L, Surf.WALL_R -> {
                lp.y -= cdir * sp
                if (cdir > 0 && lp.y <= 0) {                       // llegó arriba
                    lp.y = 0
                    if (Random.nextInt(100) < 60) { cdir = if (surf == Surf.WALL_R) -1 else 1; surf = Surf.CEIL }
                    else release()
                } else if (cdir < 0 && lp.y >= wallBottom()) {     // bajó hasta el suelo
                    dir = if (surf == Surf.WALL_L) 1 else -1
                    lp.y = groundY(); surf = Surf.FLOOR; setState(State.IDLE)
                } else if (cdir > 0 && now > stateUntil) {         // se cansa: baja o se suelta
                    if (Random.nextBoolean()) cdir = -1 else release()
                    stateUntil = now + 4000
                }
            }
            Surf.CEIL -> {
                lp.x += cdir * sp
                if (lp.x <= 0) { lp.x = 0; surf = Surf.WALL_L; cdir = -1 }
                else if (lp.x >= screenW - lp.width) { lp.x = screenW - lp.width; surf = Surf.WALL_R; cdir = -1 }
                else if (now > stateUntil) { if (Random.nextInt(100) < 35) release(); stateUntil = now + 4000 }
            }
            else -> {}
        }
    }

    private val loop = object : Runnable {
        override fun run() { step(); handler.postDelayed(this, 33) }
    }

    /** Comportamiento normal en el suelo. Devuelve true si se está moviendo. */
    private fun behave(now: Long): Boolean {
        val m = mode()
        if (m == 2) {                                   // quieto: no hace nada por su cuenta
            if (state == State.WALK) setState(State.IDLE)
            return false
        }
        if (now > stateUntil) {
            val r = Random.nextInt(100)
            if (m == 1) when {                          // solo pasea: camina, descansa, a veces ladra
                r < 60 -> setState(State.WALK)
                r < 85 -> setState(State.IDLE)
                r < 95 -> setState(State.SLEEP)
                else -> { setState(State.IDLE); ladrar() }
            } else when {
                r < 30 && tryHop() -> { setState(State.IDLE); stateUntil = now + 2500 }   // se sube a algo
                r < 35 -> setState(State.WALK)
                r < 60 -> setState(State.IDLE)
                r < 75 -> setState(State.SLEEP)
                r < 90 -> { setState(State.IDLE); jump() }
                else -> { setState(State.IDLE); ladrar() }
            }
        }
        if (state == State.WALK) {
            val stepPx = dir * dp(2)
            val feet = lp.y + lp.height
            if (!walkOff && usePlatforms() &&
                support(lp.x + lp.width / 2 + stepPx, feet, dp(24)) > feet + dp(24)) {
                dir = -dir                                  // borde de una plataforma: da la vuelta
                return true
            }
            lp.x += stepPx
            val atL = lp.x <= 0
            val atR = lp.x >= screenW - lp.width
            if (atL || atR) {
                val onBase = feet >= baseFeet() - dp(2)     // solo trepa la pared de la pantalla desde el suelo
                if (m == 0 && onBase && Random.nextInt(100) < 90) { startClimb(atL); return true }   // casi siempre trepa
                clampX(); dir = if (atL) 1 else -1
            }
            return true
        }
        return false
    }

    /** Persigue el dedo en modo juego. Devuelve true si se está moviendo. */
    private fun chase(now: Long): Boolean {
        if (now > playUntil) { endPlay(); return false }
        val dx = targetX - (lp.x + lp.width / 2)
        var moving = false
        chaseFast = false
        if (abs(dx) > dp(24)) {
            dir = if (dx > 0) 1 else -1
            val fast = abs(dx) > dp(90)
            lp.x += dir * min(if (fast) dp(9) else dp(5), abs(dx).toInt())
            clampX()
            moving = true
            chaseFast = fast
        }
        // si el dedo está más arriba, salta cuando esté debajo
        if (targetY < lp.y - dp(20) && abs(dx) < dp(80) && now - lastJumpAt > 800) {
            jump(); lastJumpAt = now
        }
        return moving
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        updateFood(now)
        updateBall()
        if (hideMode == HIDE_COUNT && now >= hideEnd) beginHidden(now)
        if (hideMode == HIDE_HIDDEN) { stepHidden(now); return }
        var moving = false

        if (!dragging) {
            val feet = lp.y + lp.height
            val sFeet = if (vy < 0f) Int.MAX_VALUE else support(lp.x + lp.width / 2, feet, dp(24))
            val airborne = vy < 0f || feet < sFeet - 1
            if (surf != Surf.FLOOR) {              // trepando por paredes / techo
                grounded = false
                if (mode() != 0) release() else { moving = true; climb(now) }
            } else if (airborne) {                        // gravedad, saltos y lanzamientos
                grounded = false
                vy += dpf(0.9f)
                var ny = lp.y + vy
                if (vy > 0f && ny + lp.height >= sFeet) {
                    ny = (sFeet - lp.height).toFloat(); vy = 0f
                    if (sFeet < baseFeet() - dp(2)) vx *= 0.25f    // aterriza suave sobre una app
                }
                lp.y = ny.toInt().coerceAtLeast(0)
                lp.x += vx.toInt()
                if (lp.x < 0) { lp.x = 0; vx = -vx * 0.6f }
                if (lp.x > screenW - lp.width) { lp.x = (screenW - lp.width).coerceAtLeast(0); vx = -vx * 0.6f }
            } else {
                grounded = true
                lp.y = sFeet - lp.height
                vy = 0f
                if (abs(vx) > 0.5f) {              // fricción tras un lanzamiento
                    lp.x += vx.toInt(); clampX(); vx *= 0.85f
                } else vx = 0f
                moving = if (playing) chase(now)
                    else if (food.isNotEmpty() && mode() != 2) goEat(now)
                    else if (ballMode) ballBehave(now)
                    else if (hideMode == HIDE_COUNT) hideRun(now)
                    else behave(now)
            }
            applyPos()
        }

        val onGround = !dragging && (surf != Surf.FLOOR || grounded)

        val running = (playing || food.isNotEmpty() || ballMode || hideMode == HIDE_COUNT) && chaseFast && moving && surf == Surf.FLOOR

        // Sprite: dormido / caminando (2 cuadros alternados) / quieto
        val wanted = when {
            state == State.SLEEP && !playing -> R.drawable.husky_sleep
            moving && onGround ->
                if ((now / (if (running) 80 else 160)) % 2 == 0L) R.drawable.husky_walk1 else R.drawable.husky_walk2
            else -> R.drawable.husky
        }
        if (wanted != currentSprite) { currentSprite = wanted; img.setImageResource(wanted) }

        // Animación "viva"
        var ty = 0f; var rot = 0f; var sy = 1f; var sx = 1f
        if (running && onGround) {                  // corriendo: zancadas más grandes, inclinado hacia adelante
            ty = -abs(sin(now / 70.0)).toFloat() * dpf(10f)
            rot = dir * 9f + sin(now / 90.0).toFloat() * 2f
            sx = 1.06f; sy = 0.96f + 0.06f * abs(sin(now / 70.0)).toFloat()
        } else if (moving && onGround) {
            ty = if (surf == Surf.FLOOR) -abs(sin(now / 110.0)).toFloat() * dpf(5f) else 0f
            rot = sin(now / 160.0).toFloat() * 3f
        } else if (!onGround && !dragging) {
            rot = (vx * 1.2f).coerceIn(-25f, 25f)
        } else if (state == State.IDLE) {
            sy = 1f + 0.02f * sin(now / 450.0).toFloat()
        } else if (state == State.SLEEP) {
            sy = 1f + 0.03f * sin(now / 900.0).toFloat()
        }
        if (now < barkUntil) {                      // saltito al ladrar
            val p = 1f - (barkUntil - now) / 350f
            ty -= sin(PI * p).toFloat().coerceAtLeast(0f) * dpf(26f)
        }
        val onSurf = surf != Surf.FLOOR
        img.pivotX = img.width / 2f
        img.pivotY = if (onSurf) img.height / 2f else img.height.toFloat()
        val surfAngle = when (surf) { Surf.FLOOR -> 0f; Surf.WALL_R -> -90f; Surf.WALL_L -> 90f; Surf.CEIL -> 180f }
        val face = when (surf) { Surf.FLOOR -> dir; Surf.WALL_R -> cdir; Surf.WALL_L -> -cdir; Surf.CEIL -> -cdir }
        img.translationX = when (surf) { Surf.WALL_R -> dpf(5f); Surf.WALL_L -> -dpf(5f); else -> 0f }
        img.translationY = ty - (if (onSurf) dpf(40f) else 0f)
        img.rotation = surfAngle + rot
        img.scaleY = sy
        img.scaleX = if (face >= 0) sx else -sx

        // Globo de texto (solo toca la vista si cambia algo)
        val show = now < bubbleUntil && surf != Surf.CEIL
        if (show && bubble.text.toString() != bubbleText) bubble.text = bubbleText
        val vis = if (show) View.VISIBLE else View.INVISIBLE
        if (bubble.visibility != vis) bubble.visibility = vis
    }

    // ---------------- Notificación obligatoria ----------------
    private fun startForegroundNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Mascota", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, HuskyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Despedir", stop).build()
        val feedPi = PendingIntent.getService(
            this, 1, Intent(this, HuskyService::class.java).setAction(ACTION_FEED),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val feedAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_add),
            "🍖 Croquetas", feedPi).build()
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("${petName()} está contigo 🐕")
            .setContentText("Dale croquetas o toca \"Despedir\" para quitarlo")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(feedAction)
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Platforms.active = false
        Platforms.rects = emptyList()
        removeFoodLayer()
        feedBtn?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hideLove()
        clearHunt()
        hideTreasure()
        stopBall()
        hideMode = HIDE_OFF
        touchLayer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        if (::root.isInitialized) try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
