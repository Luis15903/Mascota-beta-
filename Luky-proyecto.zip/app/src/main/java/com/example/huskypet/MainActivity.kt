package com.example.huskypet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("luky", MODE_PRIVATE) }
    private lateinit var titleView: TextView
    private lateinit var a11yStatus: TextView

    // colores sacados del atardecer del fondo
    private val orange = Color.parseColor("#F5A623")
    private val teal = Color.parseColor("#2BC4B4")
    private val cream = Color.parseColor("#FFD08A")
    private val ink = Color.parseColor("#2B1238")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun petName() = (prefs.getString("name", "Luky") ?: "Luky").ifBlank { "Luky" }

    private fun pill(color: Int, filled: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(30).toFloat()
        if (filled) setColor(color)
        else { setColor(Color.TRANSPARENT); setStroke(dp(2), color) }
    }

    private fun bigButton(label: String, color: Int, filled: Boolean, textColor: Int? = null, onClick: () -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor ?: if (filled) Color.WHITE else color)
            background = pill(color, filled)
            setOnClickListener { onClick() }
        }

    private fun LinearLayout.addSpaced(v: View, top: Int, h: Int = LinearLayout.LayoutParams.WRAP_CONTENT) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) })
    }

    private fun card(build: LinearLayout.() -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(18))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#B3180B2B"))
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.parseColor("#44FFFFFF"))
        }
        build()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(cream)
    }

    private fun body(t: String) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(Color.parseColor("#E6FFFFFF"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // pantalla completa: el fondo llega hasta arriba y abajo
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val bg = ImageView(this).apply {
            setImageResource(R.drawable.fondo)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(72))
        }

        titleView = TextView(this).apply {
            text = "🐕 ${petName()}"
            textSize = 38f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(12f, 0f, 3f, Color.parseColor("#99000000"))
        }
        col.addSpaced(titleView, 0)
        col.addSpaced(TextView(this).apply {
            text = "tu husky de pantalla"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(cream)
            setShadowLayer(8f, 0f, 2f, Color.parseColor("#99000000"))
        }, 2)

        // --- Activar / Desactivar (bien separados) ---
        col.addSpaced(card {
            addSpaced(bigButton("Activar mascota", teal, true, ink) { activar(null) }, 0, dp(60))
            addSpaced(View(this@MainActivity), 0, dp(24))
            addSpaced(bigButton("Desactivar mascota", Color.parseColor("#FF7A7A"), false) {
                stopService(Intent(this@MainActivity, HuskyService::class.java))
                Toast.makeText(this@MainActivity, "${petName()} se fue a descansar", Toast.LENGTH_SHORT).show()
            }, 0, dp(60))
        }, 24)

        // --- Croquetas ---
        col.addSpaced(card {
            addSpaced(label("Croquetas 🍖"), 0)
            addSpaced(body("Échale croquetas y ${petName()} corre a comérselas. También puedes dárselas desde la notificación, sin salir de la app que estés usando."), 4)
            addSpaced(bigButton("🍖 Echar croquetas", orange, true, ink) { activar(HuskyService.ACTION_FEED) }, 12, dp(56))
        }, 16)

        // --- Búsqueda del tesoro (opción aparte) ---
        col.addSpaced(card {
            addSpaced(label("Búsqueda del tesoro ✨"), 0)
            addSpaced(body("${petName()} esconde 2 cofres (L y A) en cualquier parte de la pantalla, incluso sobre otras apps. Encuéntralos y tócalos para ver tu sorpresa."), 4)
            addSpaced(bigButton("Buscar el tesoro", cream, true, ink) { activar(HuskyService.ACTION_HUNT) }, 12, dp(56))
        }, 16)

        // --- Modos de juego ---
        col.addSpaced(card {
            addSpaced(label("Jugar con ${petName()} 🎮"), 0)
            addSpaced(body("Elige un juego: la pelota o el escondite. Al elegirlo, la app se va a segundo plano y ${petName()} juega sobre tu pantalla."), 4)
            addSpaced(bigButton("Modos de juego", teal, true, ink) { mostrarModos() }, 12, dp(56))
        }, 16)

        // --- Nombre ---
        val nameBox = EditText(this).apply {
            setSingleLine(true)
            setText(petName())
            hint = "Luky"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#88FFFFFF"))
            backgroundTintList = ColorStateList.valueOf(orange)
            filters = arrayOf(InputFilter.LengthFilter(16))
        }
        col.addSpaced(card {
            addSpaced(label("Nombre de tu mascota"), 0)
            addSpaced(nameBox, 4)
            addSpaced(bigButton("Guardar nombre", cream, false) {
                val n = nameBox.text.toString().trim().ifBlank { "Luky" }
                prefs.edit().putString("name", n).apply()
                titleView.text = "🐕 $n"
                Toast.makeText(this@MainActivity, "Listo, se llama $n", Toast.LENGTH_SHORT).show()
            }, 8, dp(48))
        }, 16)

        // --- Modo ---
        col.addSpaced(card {
            addSpaced(label("¿Cómo quieres que se porte?"), 0)
            val opciones = listOf(
                "🐾 Libre (camina, salta y trepa)",
                "🚶 Solo pasea (camina, sin trepar ni saltar)",
                "🛑 Quieto (se queda donde lo dejes)"
            )
            val radios = opciones.map { t ->
                RadioButton(this@MainActivity).apply {
                    text = t; textSize = 15f; id = View.generateViewId()
                    setTextColor(Color.WHITE)
                    buttonTintList = ColorStateList.valueOf(orange)
                }
            }
            val group = RadioGroup(this@MainActivity).apply { orientation = RadioGroup.VERTICAL }
            radios.forEach { group.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48))) }
            radios[prefs.getInt("mode", 0).coerceIn(0, 2)].isChecked = true
            group.setOnCheckedChangeListener { _, id ->
                val i = radios.indexOfFirst { it.id == id }
                if (i >= 0) prefs.edit().putInt("mode", i).apply()   // el servicio lo lee al instante
            }
            addSpaced(group, 4)
        }, 16)

        // --- Trepar en otras apps (necesita accesibilidad) ---
        a11yStatus = body("")
        col.addSpaced(card {
            addSpaced(label("Trepar en otras apps"), 0)
            addSpaced(a11yStatus, 4)
            addSpaced(bigButton("Activar trepar en apps", cream, false) {
                Toast.makeText(this@MainActivity, "Busca \"Luky: trepar en apps\" y actívalo", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, 10, dp(48))
            addSpaced(bigButton("¿No te deja activarlo?", cream, false) {
                Toast.makeText(this@MainActivity, "Toca ⋮ (arriba a la derecha) → Permitir ajustes restringidos", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }, 8, dp(48))
        }, 16)

        // --- Ayuda ---
        col.addSpaced(TextView(this).apply {
            text = "Modos de juego: pelota (arrástrala y suéltala, te la trae) y escondite (cuenta hasta 10 y búscalo)\n" +
                "Toque: ladra\n" +
                "Mantener: duerme / despierta\n" +
                "Arrastrar y soltar: lo lanzas\n" +
                "Doble toque: modo juego (te persigue el dedo)\n" +
                "En modo juego, dibuja un corazón con el dedo 💕\n" +
                "Modo Libre + accesibilidad: se sube a botones, textos e íconos de otras apps"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E6FFFFFF"))
            setShadowLayer(8f, 0f, 2f, Color.parseColor("#B3000000"))
        }, 24)

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        }
        setContentView(FrameLayout(this).apply {
            addView(bg, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(scroll, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        })
    }

    override fun onResume() {
        super.onResume()
        val on = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(LukyAccessibilityService::class.java.name)
        a11yStatus.text = if (on) "✅ Activado: ${petName()} se puede subir a las apps"
        else "⚪ Desactivado: ${petName()} solo trepa por los bordes de la pantalla"
    }

    private fun activar(action: String?): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa \"Mostrar sobre otras apps\" y vuelve a tocar el botón", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val i = Intent(this, HuskyService::class.java)
        if (action != null) i.action = action
        startForegroundService(i)
        Toast.makeText(this, when (action) {
            HuskyService.ACTION_FEED -> "¡Croquetas para ${petName()}! 🍖"
            HuskyService.ACTION_HUNT -> "¡${petName()} escondió 2 cofres! Búscalos: L y A"
            HuskyService.ACTION_BALL -> "¡Pelota lista! Arrástrala y suéltala para tirarla"
            HuskyService.ACTION_HIDE -> "¡Cuenta hasta 10! ${petName()} se va a esconder"
            else -> "¡${petName()} ya está en tu pantalla!"
        }, Toast.LENGTH_LONG).show()
        return true
    }

    private fun mostrarModos() {
        val items = arrayOf(
            "🎾 Pelota\nla tiras y ${petName()} te la trae",
            "🙈 Escondite\n${petName()} se esconde y tú lo buscas"
        )
        android.app.AlertDialog.Builder(this)
            .setTitle("Modos de juego")
            .setItems(items) { _, which ->
                val a = if (which == 0) HuskyService.ACTION_BALL else HuskyService.ACTION_HIDE
                if (activar(a)) window.decorView.postDelayed({ moveTaskToBack(true) }, 500)   // sale de la app
            }
            .show()
    }
}
