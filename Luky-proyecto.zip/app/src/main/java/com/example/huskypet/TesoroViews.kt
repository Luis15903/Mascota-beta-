package com.example.huskypet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Destello de 4 puntas (lados curvos hacia adentro). Se reutiliza el mismo Path para no crear objetos por cuadro. */
internal class Sparkle {
    private val path = Path()

    fun draw(c: Canvas, cx: Float, cy: Float, r: Float, paint: Paint) {
        val k = r * 0.2f
        path.reset()
        path.moveTo(cx, cy - r)
        path.quadTo(cx + k, cy - k, cx + r, cy)
        path.quadTo(cx + k, cy + k, cx, cy + r)
        path.quadTo(cx - k, cy + k, cx - r, cy)
        path.quadTo(cx - k, cy - k, cx, cy - r)
        path.close()
        c.drawPath(path, paint)
    }
}

private val PALETA_ESTRELLAS = intArrayOf(
    Color.WHITE,
    Color.parseColor("#FFD08A"),   // crema del atardecer de la app
    Color.parseColor("#9FF3EA"),   // verde agua de la app
    Color.parseColor("#FFF3C4")
)

/**
 * Cielo de la pantalla final: estrellas que titilan y cometas que cruzan en diagonal.
 * Se anima solo mientras está en pantalla.
 */
internal class StarFieldView(ctx: Context) : View(ctx) {

    private class Star(val x: Float, val y: Float, val r: Float, val phase: Float, val speed: Float, val color: Int)
    private class Comet(var x: Float, var y: Float, val vx: Float, val vy: Float,
                        val ux: Float, val uy: Float, val r: Float, val color: Int)

    private val d = resources.displayMetrics.density
    private val stars = ArrayList<Star>()
    private val comets = ArrayList<Comet>()
    private val sparkle = Sparkle()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var last = 0L
    private var nextComet = 0L
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            advance()
            invalidate()
            postOnAnimation(this)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        stars.clear()
        val n = (w * h / (d * d * 5200f)).toInt().coerceIn(40, 110)
        repeat(n) {
            stars.add(Star(
                x = Random.nextFloat() * w,
                y = Random.nextFloat() * h,
                r = d * (1.1f + Random.nextFloat() * 2.4f),
                phase = Random.nextFloat() * (2f * PI.toFloat()),
                speed = 0.8f + Random.nextFloat() * 1.8f,
                color = PALETA_ESTRELLAS.random()
            ))
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        last = SystemClock.uptimeMillis()
        nextComet = last + 400
        postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    private fun spawnComet() {
        val w = width.toFloat(); val h = height.toFloat()
        val ang = Math.toRadians(22.0 + Random.nextDouble() * 28.0)       // inclinación respecto a la horizontal
        val speed = d * (520f + Random.nextFloat() * 380f)
        val ux = (-cos(ang)).toFloat(); val uy = sin(ang).toFloat()       // van de arriba-derecha a abajo-izquierda
        val fromTop = Random.nextBoolean()
        val sx = if (fromTop) w * (0.35f + Random.nextFloat() * 0.75f) else w + d * 24f
        val sy = if (fromTop) -d * 24f else h * Random.nextFloat() * 0.5f
        comets.add(Comet(sx, sy, ux * speed, uy * speed, ux, uy,
            d * (2.0f + Random.nextFloat() * 1.4f), PALETA_ESTRELLAS.random()))
    }

    private fun advance() {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - last) / 1000f).coerceIn(0f, 0.05f)
        last = now
        val it = comets.iterator()
        while (it.hasNext()) {
            val c = it.next()
            c.x += c.vx * dt
            c.y += c.vy * dt
            if (c.x < -d * 160f || c.y > height + d * 160f) it.remove()
        }
        if (now >= nextComet && comets.size < 5) {
            spawnComet()
            nextComet = now + Random.nextLong(450, 1500)
        }
    }

    override fun onDraw(c: Canvas) {
        val t = SystemClock.uptimeMillis() / 1000f

        for (s in stars) {
            val tw = 0.5f + 0.5f * sin(t * s.speed + s.phase)
            paint.color = s.color
            paint.alpha = (50 + 205 * tw * tw).toInt()
            val r = s.r * (0.65f + 0.35f * tw)
            if (s.r > d * 2.3f) sparkle.draw(c, s.x, s.y, r * 2.3f, paint) else c.drawCircle(s.x, s.y, r, paint)
        }

        val segs = 18
        val gap = d * 5f
        for (k in comets) {
            for (j in 0 until segs) {
                val f = 1f - j / segs.toFloat()
                paint.color = k.color
                paint.alpha = (230 * f * f).toInt()
                c.drawCircle(k.x - k.ux * gap * j, k.y - k.uy * gap * j, k.r * (0.3f + 0.7f * f), paint)
            }
            paint.color = Color.WHITE
            paint.alpha = 255
            sparkle.draw(c, k.x, k.y, k.r * 3.4f, paint)
        }
    }
}

/**
 * Cofre del tesoro dibujado con Canvas (sin imágenes). Lleva una letra en la cerradura,
 * se mece suave, destella, y al abrirlo levanta la tapa y suelta un estallido de estrellas.
 */
internal class ChestView(ctx: Context, private val letter: String) : View(ctx) {

    private class Spark(val ang: Float, val speed: Float, val r: Float, val color: Int)

    private val d = resources.displayMetrics.density
    private val chestPx = 64f * d
    private val sparkle = Sparkle()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(50f, 44f, 62f,
            intArrayOf(Color.parseColor("#FFF1B8"), Color.parseColor("#00FFD08A")),
            null, Shader.TileMode.CLAMP)
    }
    private val rect = RectF()
    private val lid = Path()

    private val wood = Color.parseColor("#B5602B")
    private val woodLight = Color.parseColor("#C9753A")
    private val woodDark = Color.parseColor("#7A3E1A")
    private val gold = Color.parseColor("#FFC93C")
    private val goldDark = Color.parseColor("#C98A12")

    private val born = SystemClock.uptimeMillis()
    private var openStart = 0L
    private val burst = ArrayList<Spark>()
    private var running = false

    var opened = false
        private set

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postOnAnimation(this)
        }
    }

    init {
        lid.moveTo(10f, 49f)
        lid.lineTo(10f, 38f)
        lid.quadTo(10f, 15f, 50f, 15f)
        lid.quadTo(90f, 15f, 90f, 38f)
        lid.lineTo(90f, 49f)
        lid.close()
    }

    fun open() {
        if (opened) return
        opened = true
        openStart = SystemClock.uptimeMillis()
        repeat(26) {
            burst.add(Spark(
                ang = Random.nextFloat() * (2f * PI.toFloat()),
                speed = d * (70f + Random.nextFloat() * 190f),
                r = d * (2.2f + Random.nextFloat() * 3.4f),
                color = PALETA_ESTRELLAS.random()
            ))
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = (now - born) / 1000f
        val cx = width / 2f
        val cy = height / 2f
        val o = if (opened) {
            val x = ((now - openStart) / 420f).coerceIn(0f, 1f)
            1f - (1f - x).pow(3)                                  // abre rápido y frena al final
        } else 0f
        val bob = if (opened) 0f else sin(t * 2.4f) * 1.8f * d

        // ---- cofre (dibujado en un cuadro de 100 x 100 y escalado) ----
        val s = chestPx / 100f
        c.save()
        c.translate(cx - chestPx / 2f, cy - chestPx / 2f + bob)
        c.scale(s, s)

        if (o > 0f) {                                             // resplandor de adentro
            glow.alpha = (255 * o).toInt()
            c.drawCircle(50f, 44f, 62f, glow)
        }

        // cuerpo
        rect.set(10f, 46f, 90f, 90f)
        p.style = Paint.Style.FILL
        p.color = wood
        c.drawRoundRect(rect, 6f, 6f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f
        p.color = woodDark
        c.drawLine(12f, 62f, 88f, 62f, p)
        c.drawLine(12f, 76f, 88f, 76f, p)
        c.drawRoundRect(rect, 6f, 6f, p)

        // interior con monedas (se ve al abrir)
        if (o > 0f) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#3A1A08")
            rect.set(12f, 42f, 88f, 52f)
            c.drawOval(rect, p)
            p.color = gold
            p.alpha = (255 * o).toInt()
            rect.set(16f, 38f, 84f, 51f)
            c.drawOval(rect, p)
            p.alpha = 255
        }

        // bandas doradas del cuerpo
        p.style = Paint.Style.FILL
        p.color = gold
        c.drawRect(20f, 48f, 29f, 89f, p)
        c.drawRect(71f, 48f, 80f, 89f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        p.color = goldDark
        c.drawRect(20f, 48f, 29f, 89f, p)
        c.drawRect(71f, 48f, 80f, 89f, p)

        // placa con la letra
        rect.set(39f, 51f, 61f, 75f)
        p.style = Paint.Style.FILL
        p.color = gold
        c.drawRoundRect(rect, 5f, 5f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f
        p.color = goldDark
        c.drawRoundRect(rect, 5f, 5f, p)
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#5A2E0B")
        p.textAlign = Paint.Align.CENTER
        p.isFakeBoldText = true
        p.textSize = 19f
        c.drawText(letter, 50f, 69f, p)
        p.isFakeBoldText = false

        // tapa: gira sobre la esquina izquierda
        c.save()
        c.rotate(-38f * o, 10f, 49f)
        p.style = Paint.Style.FILL
        p.color = woodLight
        c.drawPath(lid, p)
        c.save()
        c.clipPath(lid)
        p.color = gold
        c.drawRect(20f, 10f, 29f, 49f, p)
        c.drawRect(71f, 10f, 80f, 49f, p)
        c.restore()
        p.color = gold
        c.drawRect(10f, 44f, 90f, 49f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f
        p.color = woodDark
        c.drawPath(lid, p)
        c.restore()

        c.restore()

        // ---- destellos alrededor mientras está cerrado ----
        if (!opened) {
            for (i in 0 until 3) {
                val a = 0.5f + 0.5f * sin(t * 3f + i * 2.1f)
                p.style = Paint.Style.FILL
                p.color = if (i == 1) Color.parseColor("#9FF3EA") else Color.WHITE
                p.alpha = (40 + 215 * a * a).toInt()
                val px = cx + (if (i == 0) -0.5f else if (i == 1) 0.46f else 0.12f) * chestPx
                val py = cy + (if (i == 0) -0.42f else if (i == 1) -0.5f else -0.62f) * chestPx
                sparkle.draw(c, px, py, d * (3.5f + 2f * a), p)
            }
            p.alpha = 255
        }

        // ---- estallido de estrellas al abrir ----
        if (opened) {
            val age = (now - openStart) / 1000f
            val life = 1.15f
            if (age < life) {
                p.style = Paint.Style.FILL
                for (b in burst) {
                    val x = cx + cos(b.ang) * b.speed * age
                    val y = cy - 6f * d + sin(b.ang) * b.speed * age + 0.5f * d * 220f * age * age
                    p.color = b.color
                    p.alpha = (255 * (1f - age / life)).toInt().coerceIn(0, 255)
                    sparkle.draw(c, x, y, b.r * (1.6f - 0.8f * age / life), p)
                }
                p.alpha = 255
            }
        }
    }
}
