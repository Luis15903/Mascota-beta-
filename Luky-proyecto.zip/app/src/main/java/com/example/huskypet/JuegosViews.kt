package com.example.huskypet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.min

/** Pelota de tenis dibujada con Canvas. `angle` la hace rodar (las costuras giran, la luz no). */
internal class BallView(ctx: Context) : View(ctx) {

    var angle = 0f

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val seam = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#F4F7E4")
        strokeCap = Paint.Cap.ROUND
    }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        alpha = 110
    }
    private val clip = Path()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val r = min(w, h) / 2f
        body.shader = RadialGradient(
            w / 2f - r * 0.35f, h / 2f - r * 0.4f, r * 1.5f,
            intArrayOf(Color.parseColor("#F2FF6B"), Color.parseColor("#C5DD1F"), Color.parseColor("#8FA80E")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        seam.strokeWidth = r * 0.13f
        clip.reset()
        clip.addCircle(w / 2f, h / 2f, r - 1f, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 1f
        c.drawCircle(cx, cy, r, body)

        c.save()
        c.clipPath(clip)
        c.rotate(angle, cx, cy)
        // dos arcos blancos: las costuras
        c.drawCircle(cx - r * 1.18f, cy, r * 0.98f, seam)
        c.drawCircle(cx + r * 1.18f, cy, r * 0.98f, seam)
        c.restore()

        c.drawCircle(cx - r * 0.35f, cy - r * 0.42f, r * 0.2f, shine)
    }
}
